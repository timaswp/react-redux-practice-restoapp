import React from "react";

const RestoServiceContext = React.createContext();

export default RestoServiceContext;