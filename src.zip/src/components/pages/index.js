import MainPage from './main-page';
import CartPage from './cart-page';
import ItemPage from './item-page';

export {
    MainPage,
    CartPage,
    ItemPage
};